function validateform() {
    var name = document.forms["form"]["name"].value;
	var email = document.forms["form"]["email"].value;
  
    if (name && validateEmail(email)) {
        document.getElementById("success").style.display = "flex";
        document.getElementById("error").style.display = "none";
    } else {
        document.getElementById("error").style.display = "flex";
        document.getElementById("success").style.display = "none";
    }
    return false;
}

function validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}

function closeDialog () {
    document.getElementById("success").style.display = "none";
    document.getElementById("error").style.display = "none";
}
