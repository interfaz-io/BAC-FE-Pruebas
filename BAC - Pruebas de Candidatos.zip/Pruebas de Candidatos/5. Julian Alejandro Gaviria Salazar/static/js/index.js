const revisionFormulario = () =>{
    var Nombre = document.getElementById("input-Nombre").value;
    var Email = document.getElementById("input-Email").value;
    var Mensaje = document.getElementById("MensajeEnviar");
    Mensaje.classList.remove("NoMostrar")
    if(Nombre == "" || Email == ""){
        Mensaje.innerHTML = "<div class = 'error'></div><p id = 'textoError'>No pueden haber campos vacios<p>"
    }
    else if (Email.indexOf("@") < 0) {
        Mensaje.innerHTML = "<div class = 'error'></div><p id = 'textoError'>El email debe contener una @<p>";
    }
    else if (Email.indexOf(".com", Email.indexOf("@")) < 0 && 
             Email.indexOf(".cc", Email.indexOf("@")) < 0 &&
             Email.indexOf(".co", Email.indexOf("@")) < 0 && 
             Email.indexOf(".es", Email.indexOf("@")) < 0) {
        Mensaje.innerHTML = "<div class = 'error'></div><p id = 'textoError'>El email debe contener .com, .co o .es detras del @<p>";
    }
    else{
        Mensaje.innerHTML = "<div class = 'correcto'></div><p id = 'textoError'>El Formulario fue enviado con exito<p>";
    }
}


//si se pulsa el boton Enviar
 $("#BotonEnviar").click(function(){
    revisionFormulario();
 });

 //Si se presiona enter en el input de email
 $("#input-Email").keydown(function(event){
    if(event.which == 13)
        revisionFormulario();
 });